
Evil DICOM
=============

A simple to use C# library for reading and manipulating DICOM files. 
Github is just the distro.

The following links will help you get started:

Project website at 
http://rexcardan.com/evildicom

Content | Link
------------- | -------------
Introductory Video | https://www.youtube.com/watch?v=rmYpxxqQ90s
Examples | http://rexcardan.com/evildicom
Online API | http://www.rexcardan.com/api/evildicom/index.html
