﻿namespace EvilDICOM.Core.Interfaces
{
    public interface IDICOMBinaryReader
    {
    }
}