﻿namespace EvilDICOM.Core.Helpers
{
    public class ExceptionHelper
    {
        public static string VRReadException = "Explicit VR syntax used but VR string is missing";
    }
}