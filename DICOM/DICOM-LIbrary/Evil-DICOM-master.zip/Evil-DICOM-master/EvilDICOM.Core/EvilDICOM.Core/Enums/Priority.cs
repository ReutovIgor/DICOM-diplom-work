﻿namespace EvilDICOM.Core.Enums
{
    public enum Priority : ushort
    {
        LOW = 2,
        MEDIUM = 0,
        HIGH = 1
    }
}