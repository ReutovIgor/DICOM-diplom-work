﻿namespace EvilDICOM.Core.Enums
{
    public enum LogPriority
    {
        NORMAL,
        WARNING,
        ERROR
    }
}